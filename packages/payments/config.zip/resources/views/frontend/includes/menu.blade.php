<a class="dropdown-item" href="{{ route('frontend.deposits.index') }}">
    <i class="far fa-arrow-alt-circle-down"></i>
    {{ __('Deposits') }}
</a>
<a class="dropdown-item" href="{{ route('frontend.withdrawals.index') }}">
    <i class="far fa-arrow-alt-circle-up"></i>
    {{ __('Withdrawals') }}
</a>