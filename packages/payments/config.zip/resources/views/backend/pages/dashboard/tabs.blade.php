<li class="nav-item">
    <a class="nav-link {{ Route::currentRouteName() == 'backend.dashboard.payments' ? 'active' : '' }}" href="{{ route('backend.dashboard.payments') }}">{{ __('Payments') }}</a>
</li>