<a class="dropdown-item" href="{{ route('backend.deposits.index') }}">{{ __('Deposits') }}</a>
<a class="dropdown-item" href="{{ route('backend.withdrawals.index') }}">{{ __('Withdrawals') }}</a>
<a class="dropdown-item" href="{{ route('backend.payment-gateways.index') }}">{{ __('Payment gateways') }}</a>
<a class="dropdown-item" href="{{ route('backend.deposit-methods.index') }}">{{ __('Deposit methods') }}</a>
<a class="dropdown-item" href="{{ route('backend.withdrawal-methods.index') }}">{{ __('Withdrawal methods') }}</a>
