<?php

namespace Packages\Payments\Events;

class WithdrawalCreated extends WithdrawalStatusChanged
{
    //
}
