<?php

namespace Packages\Payments\Events;

class DepositCompleted extends DepositStatusChanged
{
    //
}
