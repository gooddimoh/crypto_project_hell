<?php

namespace Packages\Payments\Events;

class WithdrawalCompleted extends WithdrawalStatusChanged
{
    //
}
