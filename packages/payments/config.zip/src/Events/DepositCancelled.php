<?php

namespace Packages\Payments\Events;

class DepositCancelled extends DepositStatusChanged
{
    //
}
