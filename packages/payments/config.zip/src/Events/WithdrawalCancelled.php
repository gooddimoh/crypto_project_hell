<?php

namespace Packages\Payments\Events;

class WithdrawalCancelled extends WithdrawalStatusChanged
{
    //
}
